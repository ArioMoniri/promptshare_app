import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'

// This would typically come from a database based on the ID
const mockPrompt = {
  id: '1',
  title: 'Creative Writing Prompt',
  content: 'Write a short story about a world where gravity reverses every 12 hours.',
  author: 'Alice Johnson',
  promotions: 42,
  comments: 7,
  issues: 1,
}

export default function PromptDetail({ params }: { params: { id: string } }) {
  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>{mockPrompt.title}</CardTitle>
          <p className="text-sm text-gray-500">by {mockPrompt.author}</p>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4">{mockPrompt.content}</p>
          <Textarea placeholder="Try the prompt here..." className="min-h-[100px]" />
        </CardContent>
        <CardFooter>
          <Button className="w-full">Test Prompt with OpenAI</Button>
        </CardFooter>
      </Card>
      {/* Add comment section and issue tracking here */}
    </div>
  )
}

