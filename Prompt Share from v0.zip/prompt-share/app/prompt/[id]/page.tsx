'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ThumbsUp, MessageSquare, AlertTriangle, GitFork, Star, Share2 } from 'lucide-react'

// This would typically come from a database based on the ID
const mockPrompt = {
  id: '1',
  title: 'Creative Writing Prompt',
  content: 'Write a short story about a world where gravity reverses every 12 hours.',
  author: {
    name: 'Alice Johnson',
    image: '/placeholder-avatar.jpg',
  },
  promotions: 42,
  comments: 7,
  issues: 1,
  forks: 3,
  stars: 15,
  tags: ['writing', 'creative', 'sci-fi'],
}

export default function PromptDetail({ params }: { params: { id: string } }) {
  const [promptText, setPromptText] = useState(mockPrompt.content)

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src={mockPrompt.author.image} alt={mockPrompt.author.name} />
              <AvatarFallback>{mockPrompt.author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle>{mockPrompt.title}</CardTitle>
              <p className="text-sm text-gray-500">by {mockPrompt.author.name}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="prompt">
            <TabsList>
              <TabsTrigger value="prompt">Prompt</TabsTrigger>
              <TabsTrigger value="discussion">Discussion</TabsTrigger>
              <TabsTrigger value="issues">Issues</TabsTrigger>
              <TabsTrigger value="forks">Forks</TabsTrigger>
            </TabsList>
            <TabsContent value="prompt">
              <Textarea
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                className="min-h-[200px] mb-4"
              />
              <Button className="w-full mb-4">Test Prompt with AI</Button>
              <div className="flex justify-between">
                <Button variant="outline" size="sm">
                  <ThumbsUp className="mr-2 h-4 w-4" />
                  Promote ({mockPrompt.promotions})
                </Button>
                <Button variant="outline" size="sm">
                  <Star className="mr-2 h-4 w-4" />
                  Star ({mockPrompt.stars})
                </Button>
                <Button variant="outline" size="sm">
                  <GitFork className="mr-2 h-4 w-4" />
                  Fork ({mockPrompt.forks})
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>
            </TabsContent>
            <TabsContent value="discussion">
              <p>Discussion content goes here</p>
            </TabsContent>
            <TabsContent value="issues">
              <p>Issues content goes here</p>
            </TabsContent>
            <TabsContent value="forks">
              <p>Forks content goes here</p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

