'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ThumbsUp, ThumbsDown, MessageSquare, AlertTriangle, GitFork, Star, Share2, GitPullRequest, Copy, ArrowLeft } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import TestPrompt from '@/app/components/TestPrompt'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'

// This would typically come from a database based on the ID
const mockPrompt = {
  id: '1',
  title: 'Creative Writing Prompt',
  content: 'Write a short story about a world where gravity reverses every 12 hours.',
  sRef: 'sRef_123456',
  author: {
    name: 'Alice Johnson',
    image: '/placeholder-avatar.jpg',
  },
  promotions: 42,
  downvotes: 5,
  comments: 7,
  issues: 1,
  forks: 3,
  stars: 15,
  tags: ['writing', 'creative', 'sci-fi'],
  version: '1.2.0',
  versions: [
    { version: '1.0.0', date: '2023-01-01' },
    { version: '1.1.0', date: '2023-02-15' },
    { version: '1.2.0', date: '2023-03-30' },
  ],
}

export default function PromptDetail({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [promptText, setPromptText] = useState(mockPrompt.content)
  const [sRef, setSRef] = useState(mockPrompt.sRef)
  const [selectedVersion, setSelectedVersion] = useState(mockPrompt.version)
  const [copied, setCopied] = useState(false)

  const handleVersionChange = (version: string) => {
    setSelectedVersion(version)
    // In a real app, you would fetch the content for the selected version
    setPromptText(`Content for version ${version}`)
    setSRef(`sRef for version ${version}`)
  }

  const handleSubmitPullRequest = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle pull request submission
    console.log('Pull request submitted')
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(promptText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const AnimatedButton = motion(Button)

  return (
    <div className="max-w-4xl mx-auto">
      <Button variant="ghost" size="sm" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back
      </Button>
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src={mockPrompt.author.image} alt={mockPrompt.author.name} />
              <AvatarFallback>{mockPrompt.author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-grow">
              <CardTitle>{mockPrompt.title}</CardTitle>
              <p className="text-sm text-muted-foreground">by {mockPrompt.author.name}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={handleCopy}>
              {copied ? (
                <span className="text-green-500">Copied!</span>
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="prompt">
            <TabsList>
              <TabsTrigger value="prompt">Prompt</TabsTrigger>
              <TabsTrigger value="test">Test</TabsTrigger>
              <TabsTrigger value="discussion">Discussion</TabsTrigger>
              <TabsTrigger value="issues">Issues</TabsTrigger>
              <TabsTrigger value="forks">Forks</TabsTrigger>
              <TabsTrigger value="versions">Versions</TabsTrigger>
            </TabsList>
            <TabsContent value="prompt">
              <Textarea
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                className="min-h-[200px] mb-4"
              />
              {sRef && (
                <div className="bg-muted p-2 rounded-md mb-4 flex justify-between items-center">
                  <p className="text-sm font-mono">sRef: {sRef}</p>
                  <Button variant="ghost" size="sm" onClick={() => {
                    navigator.clipboard.writeText(sRef);
                    // You can add a toast notification here to show that sRef was copied
                  }}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              )}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 mb-4">
                <AnimatedButton
                  variant="outline"
                  size="sm"
                  whileTap={{ scale: 0.9 }}
                  className="w-full"
                >
                  <ThumbsUp className="mr-2 h-4 w-4" />
                  Promote ({mockPrompt.promotions})
                </AnimatedButton>
                <AnimatedButton
                  variant="outline"
                  size="sm"
                  whileTap={{ scale: 0.9 }}
                  className="w-full"
                >
                  <ThumbsDown className="mr-2 h-4 w-4" />
                  Downvote ({mockPrompt.downvotes})
                </AnimatedButton>
                <AnimatedButton
                  variant="outline"
                  size="sm"
                  whileTap={{ scale: 0.9 }}
                  className="w-full"
                >
                  <Star className="mr-2 h-4 w-4" />
                  Star ({mockPrompt.stars})
                </AnimatedButton>
                <Button variant="outline" size="sm" className="w-full">
                  <GitFork className="mr-2 h-4 w-4" />
                  Fork ({mockPrompt.forks})
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full">
                      <GitPullRequest className="mr-2 h-4 w-4" />
                      Submit Changes
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Submit Changes</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmitPullRequest} className="space-y-4">
                      <div>
                        <Label htmlFor="title">Title</Label>
                        <Input id="title" placeholder="Enter a title for your changes" required />
                      </div>
                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" placeholder="Describe your changes" required />
                      </div>
                      <Button type="submit">Submit Pull Request</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </TabsContent>
            <TabsContent value="test">
              <TestPrompt initialPrompt={promptText} />
            </TabsContent>
            <TabsContent value="discussion">
              <p>Discussion content goes here</p>
            </TabsContent>
            <TabsContent value="issues">
              <p>Issues content goes here</p>
            </TabsContent>
            <TabsContent value="forks">
              <p>Forks content goes here</p>
            </TabsContent>
            <TabsContent value="versions">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Version History</h3>
                <ul className="space-y-2">
                  {mockPrompt.versions.map((v) => (
                    <li key={v.version} className="flex justify-between items-center">
                      <span>{v.version} - {v.date}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleVersionChange(v.version)}
                      >
                        View
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

