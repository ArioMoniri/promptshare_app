'use client'

import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import PromptCard from './components/PromptCard'

// This would typically come from an API
const mockPrompts = [
  {
    id: '1',
    title: 'Creative Writing Prompt',
    content: 'Write a short story about a world where gravity reverses every 12 hours.',
    author: {
      name: 'Alice Johnson',
      image: '/placeholder-avatar.jpg',
    },
    category: 'Writing',
    promotions: 42,
    downvotes: 5,
    comments: 7,
    issues: 1,
    forks: 3,
    stars: 15,
    tags: ['writing', 'creative', 'sci-fi'],
    version: '1.0.0',
  },
  // Add more mock prompts as needed
]

const categories = ['All', 'Writing', 'Coding', 'Image Generation', 'Audio Generation', 'Video Generation', 'Other']

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')

  const filteredPrompts = mockPrompts.filter(prompt =>
    (selectedCategory === 'All' || prompt.category === selectedCategory) &&
    (prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
     prompt.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
     prompt.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())))
  )

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Welcome to PromptShare</h1>
      <div className="flex space-x-4">
        <Input
          type="text"
          placeholder="Search prompts..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-grow"
        />
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map(category => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredPrompts.map((prompt) => (
          <PromptCard key={prompt.id} {...prompt} />
        ))}
      </div>
    </div>
  )
}

