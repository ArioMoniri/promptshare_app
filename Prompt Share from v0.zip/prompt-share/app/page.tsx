import PromptFeed from './components/PromptFeed'

export default function Home() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Welcome to PromptShare</h1>
      <PromptFeed />
    </div>
  )
}

