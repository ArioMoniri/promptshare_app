'use client'

import Link from 'next/link'
import { useTheme } from 'next-themes'
import { Button } from '@/components/ui/button'
import { Moon, Sun, TrendingUpIcon as Trending } from 'lucide-react'
import CreatePromptDialog from './CreatePromptDialog'

export default function Header() {
  const { theme, setTheme } = useTheme()

  return (
    <header className="bg-background border-b">
      <div className="container mx-auto px-4 py-6 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-foreground">
          PromptShare
        </Link>
        <nav className="flex items-center space-x-4">
          <Button asChild variant="ghost" className="text-foreground hover:text-primary">
            <Link href="/trending">
              <Trending className="mr-2 h-4 w-4" />
              Trending
            </Link>
          </Button>
          <CreatePromptDialog />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          >
            <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
        </nav>
      </div>
    </header>
  )
}

