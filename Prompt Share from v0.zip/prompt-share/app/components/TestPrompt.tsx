'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Loader2 } from 'lucide-react'

interface TestPromptProps {
  initialPrompt: string
}

export default function TestPrompt({ initialPrompt }: TestPromptProps) {
  const [prompt, setPrompt] = useState(initialPrompt)
  const [response, setResponse] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleTest = async () => {
    setIsLoading(true)
    // In a real application, you would call your AI service here
    await new Promise(resolve => setTimeout(resolve, 2000)) // Simulating API call
    setResponse('This is a mock response from the AI. Replace this with actual AI integration.')
    setIsLoading(false)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Test Prompt</CardTitle>
      </CardHeader>
      <CardContent>
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter your prompt here"
          className="min-h-[100px] mb-4"
        />
        <Button onClick={handleTest} className="w-full" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Testing...
            </>
          ) : (
            'Test Prompt'
          )}
        </Button>
      </CardContent>
      {response && (
        <CardFooter>
          <div className="w-full">
            <h4 className="font-semibold mb-2">AI Response:</h4>
            <p className="text-sm text-muted-foreground">{response}</p>
          </div>
        </CardFooter>
      )}
    </Card>
  )
}

