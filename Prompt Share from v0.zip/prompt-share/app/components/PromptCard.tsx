import Link from 'next/link'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ThumbsUp, ThumbsDown, MessageSquare, AlertTriangle, GitFork, Star, Share2 } from 'lucide-react'

interface PromptCardProps {
  id: string
  title: string
  content: string
  sRef?: string
  author: {
    name: string
    image: string
  }
  promotions: number
  downvotes: number
  comments: number
  issues: number
  forks: number
  stars: number
  tags: string[]
  version: string
}

export default function PromptCard({ id, title, content, sRef, author, promotions, downvotes, comments, issues, forks, stars, tags, version }: PromptCardProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <Avatar>
            <AvatarImage src={author.image} alt={author.name} />
            <AvatarFallback>{author.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-lg">{title}</CardTitle>
            <p className="text-sm text-muted-foreground">by {author.name}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-foreground mb-4">{content.substring(0, 100)}...</p>
        {sRef && (
          <div className="bg-muted p-2 rounded-md mb-4">
            <p className="text-sm font-mono">sRef: {sRef}</p>
          </div>
        )}
        <div className="flex flex-wrap gap-2 mb-2">
          {tags.map((tag) => (
            <span key={tag} className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs">
              {tag}
            </span>
          ))}
        </div>
        <p className="text-sm text-muted-foreground">Version: {version}</p>
      </CardContent>
      <CardFooter className="flex justify-between flex-wrap gap-2">
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm">
            <ThumbsUp className="mr-2 h-4 w-4" />
            {promotions}
          </Button>
          <Button variant="ghost" size="sm">
            <ThumbsDown className="mr-2 h-4 w-4" />
            {downvotes}
          </Button>
        </div>
        <Button variant="ghost" size="sm">
          <MessageSquare className="mr-2 h-4 w-4" />
          {comments}
        </Button>
        <Button variant="ghost" size="sm">
          <AlertTriangle className="mr-2 h-4 w-4" />
          {issues}
        </Button>
        <Button variant="ghost" size="sm">
          <GitFork className="mr-2 h-4 w-4" />
          {forks}
        </Button>
        <Button variant="ghost" size="sm">
          <Star className="mr-2 h-4 w-4" />
          {stars}
        </Button>
        <Button variant="ghost" size="sm">
          <Share2 className="mr-2 h-4 w-4" />
          Share
        </Button>
        <Button asChild>
          <Link href={`/prompt/${id}`}>View</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

